@extends('layouts.main')
@section('content')


<div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
        <div class="x_title">

          <h2>  مديونيات الموردين </h2>
          <ul class="nav navbar-right panel_toolbox">
{{--            <li> <a href="{{ url('admin/depts/create') }}"> <i class="fa fa-plus"></i>اضافه</a></li>--}}


            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
            </li>

          </ul>
          <div class="clearfix"></div>
        </div>

        <div class="x_content">

          <table id="table_id" class="table table-striped">
            <thead  class="thead-light">
              <tr>
              <th>#</th>
              <th> اسم المورد </th>
               <th>المخزن </th>
              <th> الاجمالى </th>
              <th> المبلغ المدفوع</th>
              <th>متبقي </th>
              <th>  التاريخ</th>
              <th> الحاله </th>

              <th width="15%">التحكم</th>

            </tr>
          </thead>
          <tbody>
          @foreach($depts as $i=>$dept)

            <tr>
                <th scope="row">{{++$i}}</th>
                <td>{{ isset($dept->supplier) ? $dept->supplier->name : "-----" }}</td>
                 <td>{{ isset($dept->store) ? $dept->store->name : "-----" }}</td>
                 <td>{{ $dept->examination->total }}</td>
                <td>{{ $dept->examination->paid }}</td>
                <td>{{ $dept->amount }}</td>
                <td>{{$dept->created_at}}</td>
                <td> {{ $dept->examination->total == $dept->examination->paid ? " تم التحصيل " : "-----" }} </td>



                <td>
                    @if($dept->examination->total != $dept->examination->paid)
                <a href="{{url('admin/supplier_depts/'.$dept['id'].'/edit')}}" class="btn btn-success" >
                    <span class="glyphicon glyphicon-edit"></span>
                </a>
                @endif

                {{--
                <form method="POST" onclick="return confirm('هل انت متأكد؟')" action="{{ url('admin/depts/'.$dept['id']) }}"  style="display:inline" >
                <button name="_method" type="hidden" value="DELETE" class="btn btn-default btn-sm">
                <span class="glyphicon glyphicon-remove"></span>
                </button>
                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                </form> --}}

               </td>

              </tr>

          @endforeach

            </tbody>
          </table>

        </div>
        </div>
        </div>


@endsection
